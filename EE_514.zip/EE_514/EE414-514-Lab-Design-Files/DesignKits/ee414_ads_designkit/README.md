These project contain a custome ADS PDK for use in EE 414/514 at Iowa State University Dept. of Electrical and Computer Engineering. This PDK is built around the 2-layer PCB fabrication process provided by Advanced Circuits and includes a complete set of simulation models and layout artwork.

# Instructions for installing the Design Kit

For complete instructions on how to install this design kit, [refer to the wiki](https://git.ece.iastate.edu/neihart/ee414_ads_designkit/-/wikis/home)

# Change Log

**Name:** DesignKit_EE414\
**Version:** 3.1.1\
**Creation Date:** Dec. 31, 2021\
**Description:** Design kit containing component models and artwork to be used in EE414/514

## Ver. 3.1.x

11/17/23 -- The following changes were made:

  - Updates were made to the LVS rules to be more selective of which parmeters to check/ignore.
  - Updated version number to 3.1.1

11/16/23 -- The following changes were made:

  - Updated layout.prf file to load properly.
  - Updated the master substrate so that Leads and Lead2 layers were identified as non-conducting component leads. This fixed the visual offset when viewing the 3D view.
  - Created model cards for all passive elements as well as pads and deleted all corresponding schematics.
  - Updated the AEL item definition files to use the newly created model cards
  - Updated artwork for Pad2, Pad3, Pad4 to use area pins instead of just edge pins
  - Removed EE414_create_edge_port() helper function
  - Update DRC rules to make them more robust and updated default via definition so that it passes DRC
  - Updated version number to 3.1.0

## Ver. 3.0.x

09/14/2023 -- The following changes were made:
  - Bumped version to 3.0.2 in README
  - Removed code that has been commented-out in EE414_INCLUDE.ael
  - Removed a call to info_message() in boot.ael
  - Updated version number to 3.0.2 in DesignKit_EE414/eesof_lib.cfg
  - Updated version number to 3.0.2 in doc/about.txt

## Ver. 3.0.1

09/14/2023 -- The following changes were made:
  - Bumped version to 3.0.1 in README
  - Updated the circuit/ael/EE414_INCLUDE.ael file to remove an extra "/" character from the #include commands. This fixed a simulation error that occurred if the SP transistor modle was simulated with the EE414_INCLUDE element also present in the schematic.
  - Updated version number to 3.0.1 in DesignKit_EE414/eesof_lib.cfg
  - Updated version number to 3.0.1 in doc/about.txt

## Ver. 3.0

12/01/2022 -- The following changes were made:

  - Bumped version to 3.0.0
  - Replaced dot pins with edge pins for Pad2, Pad3, and Pad4
  - Replaced dot pins with area pins for Gnd_Pad
  - Replaced dot pins with area ports on all RLC element, ICs, and connectors
  - Changed the default via size in the ground pads to 25 mil
  - Updated the Leads layer to a conductor and added a layer binding to Top_Cu to aid in LVSing pads with IC components
  - Added the Leads2 layer, as a conductor, with binging to Top_Cu to aid in LVSing pads with RLC components
  - Added a simplified substrate with ideal ground cover for use in Momentum simulations
  - Added callback functions to the item definitions to Pad2, Pad3, and Pad4 to force a minimum pad with and length
  - Added callback functions to the item definition of gnd_pad to ensure minimum with and length,
     as well as a minimum via diameter and to ensure a minimum copper overlab of the via.
  - Updated the LVS rules to short the pins in schematic instances of gnd_pad to aid in LVS.
  - Updated layout preferences file.


## Ver. 2.0

9/22/2022 -- The following changes were made:
  - Fixed the unit-type in the 0603 inductor to fix problem where inductor could not be tuned.
  - Added valid parasitic component values to the parasitic_param_value.txt file. Student
     no longer need to edit this file.
  - Updated the version number to 2.0.1

8/19/2022 -- Initial release of version 2.0
