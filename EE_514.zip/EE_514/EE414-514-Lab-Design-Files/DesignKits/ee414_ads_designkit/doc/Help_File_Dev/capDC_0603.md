# CAPDC_0603

## Symbol

![cap0603](images/capDC_0603.png)

## Description

Detailed documentation can be found on the [Design Kit Wiki Page](https://git.ece.iastate.edu/neihart/ee414_ads_designkit/-/wikis/home).