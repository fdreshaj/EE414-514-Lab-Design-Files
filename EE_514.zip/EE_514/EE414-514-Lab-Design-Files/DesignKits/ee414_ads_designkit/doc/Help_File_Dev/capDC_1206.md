# CAPDC_1206

## Symbol

![cap1206](images/capDC_1206.png)

## Description

Detailed documentation can be found on the [Design Kit Wiki Page](https://git.ece.iastate.edu/neihart/ee414_ads_designkit/-/wikis/home).