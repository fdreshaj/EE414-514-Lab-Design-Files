# PAD_3

## Symbol

![pad3](images/pad_3.png)

## Description

Detailed documentation can be found on the [Design Kit Wiki Page](https://git.ece.iastate.edu/neihart/ee414_ads_designkit/-/wikis/home).